﻿Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions

Module UtilesFECHAS
    Public Function DateTime_DameFormateado(oDateTime As DateTime, Optional txtFormato As String = "yyyyMMddTHHmmss") As String
        ' Original      =   18/12/2018 13:50:43
        ' Formateado    =   20181218T135043         Con ToString("yyyyMMddTHHmmss")
        Return oDateTime.ToString(txtFormato)
    End Function
End Module
