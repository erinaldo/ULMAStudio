﻿Imports System.Collections
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.IO
Imports System.Linq
Imports System.Reflection
Imports System.Text
Imports System.Windows
Imports System.Windows.Forms
Imports System.Windows.Media.Imaging
Imports System.Xml
Imports Autodesk.Revit.ApplicationServices
'Imports Autodesk.Revit.Utility
Imports Autodesk.Revit.ApplicationServices.Application
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.DB.Architecture
Imports Autodesk.Revit.DB.Document
Imports Autodesk.Revit.DB.Electrical
Imports Autodesk.Revit.DB.Events
Imports Autodesk.Revit.DB.Mechanical
Imports Autodesk.Revit.DB.Plumbing
Imports Autodesk.Revit.DB.Structure
'Imports Autodesk.Revit.Collections
Imports Autodesk.Revit.Exceptions
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Events
Imports Autodesk.Revit.UI.Selection
Partial Public Class evRevit
    Public Shared bolDocumentCreating As Boolean = False

#Region "EVENTOS CONTROLLEDAPLICACION"
    Public Shared Sub evAppC_ApplicationInitialized(sender As Object, e As ApplicationInitializedEventArgs) Handles evAppC.ApplicationInitialized
        'System.Windows.MessageBox.Show("ControlledApplication.ApplicationInitialized")
        ' Aquí pondremos lo que queremos que carge, después de tener Revit inicializado
        ' ApplicationInitialized de Application no se activa con doble click en fichero desde explorer, este sí.
        If evAppUI Is Nothing Then
            Try
                evAppUI = New UIApplication(TryCast(sender, Autodesk.Revit.ApplicationServices.Application))
                'AddHandler evAppUI.Idling, AddressOf evAppUI_Idling
            Catch ex As Exception
                Debug.Print(ex.ToString)
            End Try
        End If
        If evApp Is Nothing Then
            Try
                evApp = TryCast(sender, Autodesk.Revit.ApplicationServices.Application)
            Catch ex As Exception
                System.Windows.MessageBox.Show(ex.ToString)
            End Try
        End If
        evRevit.SubscribeAll()
    End Sub

    Private Shared Sub evAppC_DocumentChanged(sender As Object, e As DocumentChangedEventArgs) Handles evAppC.DocumentChanged
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentChanged")      
    End Sub

    Private Shared Sub evAppC_DocumentClosed(sender As Object, e As DocumentClosedEventArgs) Handles evAppC.DocumentClosed
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentClosed")
        'If evRevit.evClose = False Then Exit Sub
        If evApp IsNot Nothing Then
            evApp.PurgeReleasedAPIObjects()
        End If
    End Sub

    Private Shared Sub evAppC_DocumentClosing(sender As Object, e As DocumentClosingEventArgs) Handles evAppC.DocumentClosing
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentClosing")
    End Sub

    Private Shared Sub evAppC_DocumentCreated(sender As Object, e As DocumentCreatedEventArgs) Handles evAppC.DocumentCreated
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentCreated")
        If e.Document IsNot Nothing Then SubscribeToDoc(e.Document)
    End Sub

    Private Shared Sub evAppC_DocumentCreating(sender As Object, e As DocumentCreatingEventArgs) Handles evAppC.DocumentCreating
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentCreating")
    End Sub

    Public Shared Sub evAppC_DocumentOpened(sender As Object, e As DocumentOpenedEventArgs) Handles evAppC.DocumentOpened
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentOpened-->Inicicado")
    End Sub
    Public Shared Sub evAppC_DocumentOpening(sender As Object, e As DocumentOpeningEventArgs) Handles evAppC.DocumentOpening
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentOpening-->Iniciado")
    End Sub

    Private Shared Sub evAppC_DocumentSaved(sender As Object, e As DocumentSavedEventArgs) Handles evAppC.DocumentSaved
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentSaved")
    End Sub

    Private Shared Sub evAppC_DocumentSavedAs(sender As Object, e As DocumentSavedAsEventArgs) Handles evAppC.DocumentSavedAs
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentSavedAs")
    End Sub

    Private Shared Sub evAppC_DocumentSaving(sender As Object, e As DocumentSavingEventArgs) Handles evAppC.DocumentSaving
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentSaving")
        'If evRevit.evSave = False Then Exit Sub
    End Sub

    Private Shared Sub evAppC_DocumentSavingAs(sender As Object, e As DocumentSavingAsEventArgs) Handles evAppC.DocumentSavingAs
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentSavingAs")
    End Sub

    Private Shared Sub evAppC_FailuresProcessing(sender As Object, e As FailuresProcessingEventArgs) Handles evAppC.FailuresProcessing
        ' System.Windows.MessageBox.Show("ControlledApplication.FailuresProcessing")
    End Sub
    Private Shared Sub evAppC_FamilyLoadedIntoDocument(sender As Object, e As FamilyLoadedIntoDocumentEventArgs) Handles evAppC.FamilyLoadedIntoDocument
        'System.Windows.MessageBox.Show("ControlledApplication.FamilyLoadedIntoDocument")
    End Sub
    Private Shared Sub evAppC_DocumentPrinted(sender As Object, e As DocumentPrintedEventArgs) Handles evAppC.DocumentPrinted
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentPrinted")
    End Sub
    Private Shared Sub evAppC_DocumentSynchronizedWithCentral(sender As Object, e As DocumentSynchronizedWithCentralEventArgs) Handles evAppC.DocumentSynchronizedWithCentral
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentSynchronizedWithCentral")
    End Sub
    '
    'DWG DWG format  
    'DWF DWF format  
    'DWFX DWFX format  
    'GBXML GBXML format  
    'FBX FBX format  
    'Image Image format  
    'DGN DGN format  
    'Civil3D Civel3D format  
    'Inventor Inventor format  
    'DXF DXF format  
    'SAT SAT format  
    'IFC IFC format  
    'NWC Navisworks format  
    Private Shared Sub evAppC_FileExported(sender As Object, e As FileExportedEventArgs) Handles evAppC.FileExported
        'System.Windows.MessageBox.Show("ControlledApplication.FileExported")
    End Sub
    Private Shared Sub evAppC_FileImported(sender As Object, e As FileImportedEventArgs) Handles evAppC.FileImported
        'System.Windows.MessageBox.Show("ControlledApplication.FileImported")
    End Sub
    Private Shared Sub evAppC_LinkedResourceOpened(sender As Object, e As LinkedResourceOpenedEventArgs) Handles evAppC.LinkedResourceOpened
        'System.Windows.MessageBox.Show("ControlledApplication.LinkedResourceOpened")
    End Sub
    Private Shared Sub evAppC_ViewPrinted(sender As Object, e As ViewPrintedEventArgs) Handles evAppC.ViewPrinted
        'System.Windows.MessageBox.Show("ControlledApplication.ViewPrinted")
    End Sub
#End Region

#Region "EVENTOS CONTROLLEDAPPLICATION DESACTIVADOS"

    Private Shared Sub evAppC_DocumentPrinting(sender As Object, e As DocumentPrintingEventArgs) Handles evAppC.DocumentPrinting
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentPrinting")
    End Sub

    Private Shared Sub evAppC_DocumentSynchronizingWithCentral(sender As Object, e As DocumentSynchronizingWithCentralEventArgs) Handles evAppC.DocumentSynchronizingWithCentral
        'System.Windows.MessageBox.Show("ControlledApplication.DocumentSynchronizingWithCentral")
    End Sub

    Private Shared Sub evAppC_ElementTypeDuplicated(sender As Object, e As ElementTypeDuplicatedEventArgs) Handles evAppC.ElementTypeDuplicated
        'System.Windows.MessageBox.Show("ControlledApplication.ElementTypeDuplicated")
    End Sub

    Private Shared Sub evAppC_ElementTypeDuplicating(sender As Object, e As ElementTypeDuplicatingEventArgs) Handles evAppC.ElementTypeDuplicating
        'System.Windows.MessageBox.Show("ControlledApplication.ElementTypeDuplicating")
    End Sub

    Private Shared Sub evAppC_FamilyLoadingIntoDocument(sender As Object, e As FamilyLoadingIntoDocumentEventArgs) Handles evAppC.FamilyLoadingIntoDocument
        'System.Windows.MessageBox.Show("ControlledApplication.FamilyLoadingIntoDocument")
    End Sub


    Private Shared Sub evAppC_FileExporting(sender As Object, e As FileExportingEventArgs) Handles evAppC.FileExporting
        'System.Windows.MessageBox.Show("ControlledApplication.FileExporting")
    End Sub


    Private Shared Sub evAppC_FileImporting(sender As Object, e As FileImportingEventArgs) Handles evAppC.FileImporting
        'System.Windows.MessageBox.Show("ControlledApplication.FileImporting")
    End Sub

    Private Shared Sub evAppC_LinkedResourceOpening(sender As Object, e As LinkedResourceOpeningEventArgs) Handles evAppC.LinkedResourceOpening
        'System.Windows.MessageBox.Show("ControlledApplication.LinkedResourceOpening")
    End Sub
    Public Shared Sub evAppCont_ProgressChanged(sender As Object, e As Autodesk.Revit.DB.Events.ProgressChangedEventArgs) Handles evAppC.ProgressChanged
        'If e.Position = e.LowerRange Then
        '    System.Windows.MessageBox.Show("ControlledApplication.ProgressChanged")
        'End If
        'If e.Caption.ToLower.StartsWith("guardar") OrElse e.Caption.ToLower.StartsWith("save") Then
        '    Debug.Print(e.Caption)
        'End If
    End Sub

    Private Shared Sub evAppC_ViewPrinting(sender As Object, e As ViewPrintingEventArgs) Handles evAppC.ViewPrinting
        'System.Windows.MessageBox.Show("ControlledApplication.ViewPrinting")
    End Sub

    Private Shared Sub evAppC_WorksharedOperationProgressChanged(sender As Object, e As WorksharedOperationProgressChangedEventArgs) Handles evAppC.WorksharedOperationProgressChanged
        'System.Windows.MessageBox.Show("ControlledApplication.WorksharedOperationProgressChanged")
    End Sub
#End Region
End Class