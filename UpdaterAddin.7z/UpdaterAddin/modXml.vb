﻿Imports System.IO
Imports System.Xml
Imports System.Xml.Linq
Imports System.Data
Imports Microsoft.VisualBasic.FileIO

Module modXml
    ' En este caso leeremos los campos 1 (ES) y 3 (Spanish)...  El 2(Español)
    Public Sub RellenaIdiomas_CSV(queFiCSV As String,
                              ByRef quecolIdiomaCod As Dictionary(Of String, String),
                              ByRef quecolCodIdioma As Dictionary(Of String, String))
        'Dim sb As New System.Text.StringBuilder()
        ''
        quecolIdiomaCod = New Dictionary(Of String, String)
        quecolCodIdioma = New Dictionary(Of String, String)
        ''
        Using reader As New Microsoft.VisualBasic.FileIO.TextFieldParser(queFiCSV)

            reader.TextFieldType = FieldType.Delimited
            reader.SetDelimiters(";") ' Los campos del archivo están separados por comas.

            ' Recorremos el archivo hasta el final del mismo.
            While Not reader.EndOfData
                Try
                    ' Obtenemos una matriz con los datos existentes en la línea actual.
                    Dim lineaActual As String() = reader.ReadFields()
                    quecolIdiomaCod.Add(lineaActual(2), lineaActual(0))
                    quecolCodIdioma.Add(lineaActual(0), lineaActual(2))
                    'For Each campo As String In lineaActual
                    'sb.AppendFormat("{0}|", campo)
                    'Next
                    'sb.AppendLine()
                Catch ex As MalformedLineException
                    MsgBox("La línea actual " & ex.Message & " no es válida.")
                End Try
            End While
        End Using
        ' Mostramos el contenido en la ventana de Salida de Visual Studio.
        'Console.WriteLine(sb.ToString())
    End Sub
    ''
    '' En este caso leeremos los campos 1 (ES) y 3 (Spanish)...  El 2(Español)
    Public Sub Formatea_CSV(queFiCSV As String,
                            Optional unidPeso As String = "",
                            Optional unidArea As String = "",
                            Optional unidLength As String = "",
                            Optional unidLengthM As String = "")
        Dim sb As New System.Text.StringBuilder()
        ''
        Using reader As New Microsoft.VisualBasic.FileIO.TextFieldParser(queFiCSV)

            reader.TextFieldType = FieldType.Delimited
            reader.SetDelimiters(";") ' Los campos del archivo están separados por comas.

            ' Recorremos el archivo hasta el final del mismo.
            Dim contador As Integer = 0
            Dim cabeceras As String() = Nothing                 '' Array con los nombres de las cabeceras.
            Dim colNoFormatear As List(Of Integer) = Nothing    '' Indice de las columnas que no hay que formatear
            Dim simPeso As String = IIf(unidPeso = "", "kg", unidPeso).ToString     'kg
            Dim simArea As String = IIf(unidArea = "", "m2", unidArea).ToString     'm2
            Dim simLength As String = IIf(unidLength = "", "mm", unidLength).ToString     '"mm"
            Dim simLengthM As String = IIf(unidLengthM = "", "m", unidLengthM).ToString     '"m"
            Try
                Dim fvOpt As New Autodesk.Revit.DB.FormatValueOptions
                fvOpt.AppendUnitSymbol = True
                If unidPeso = "" Then
                    simPeso = UnitFormatUtils.Format(evRevit.evAppUI.ActiveUIDocument.Document.GetUnits, UnitType.UT_Mass, 100, False, False, fvOpt).Split(" "c)(1)
                End If
                If unidArea = "" Then
                    simArea = UnitFormatUtils.Format(evRevit.evAppUI.ActiveUIDocument.Document.GetUnits, UnitType.UT_Area, 100, False, False, fvOpt).Split(" "c)(1)
                End If
                'simLength = UnitFormatUtils.Format(oDoc.GetUnits, UnitType.UT_Length, 100, False, False, fvOpt).Split(" "c)(1)
                Select Case evRevit.evAppUI.ActiveUIDocument.Document.GetUnits.GetFormatOptions(UnitType.UT_Length).DisplayUnits
                    Case DisplayUnitType.DUT_MILLIMETERS
                        simLength = "mm"
                    Case DisplayUnitType.DUT_CENTIMETERS
                        simLength = "cm"
                    Case DisplayUnitType.DUT_DECIMETERS
                        simLength = "dm"
                    Case DisplayUnitType.DUT_METERS
                        simLength = "m"
                    Case DisplayUnitType.DUT_DECIMAL_FEET
                        simLength = "ft"
                        simLengthM = "ft"
                    Case DisplayUnitType.DUT_DECIMAL_INCHES
                        simLength = "in"
                        simLengthM = "in"
                    Case DisplayUnitType.DUT_FEET_FRACTIONAL_INCHES
                        simLength = "ft-in" & comi
                        simLengthM = "ft-in"
                    Case DisplayUnitType.DUT_FRACTIONAL_INCHES
                        simLength = "in-in" & comi
                        simLengthM = "'"
                End Select
                fvOpt = Nothing
            Catch ex As Exception
                ''
            End Try
            Dim encontradascabeceras As Boolean = False
            ''
            While Not reader.EndOfData
                Try
                    ' Obtenemos una matriz con los datos existentes en la línea actual.
                    Dim lineaActual As String() = reader.ReadFields()
                    '' Si contiene la palabra CODE, será la fila inicial de cabeceras.
                    '' El resto de filas hacia abajo, serán datos.
                    If lineaActual(0).ToUpper.Contains("CODE") AndAlso encontradascabeceras = False Then
                        encontradascabeceras = True
                        ReDim cabeceras(lineaActual.GetUpperBound(0))
                        lineaActual.CopyTo(cabeceras, 0)
                        For x = 0 To lineaActual.Count - 1
                            Dim dato As String = lineaActual(x)
                            If dato.ToUpper = "QUANTITY" AndAlso queFiCSV.ToUpper.EndsWith("PARTS.CSV") = True Then
                                '' No ponemos las unidades en esta columna. Ya que puede llevar varias.
                            ElseIf dato.ToUpper = "AREA" AndAlso queFiCSV.ToUpper.EndsWith("AREA.CSV") = True Then
                                dato &= " (" & simArea & ")"
                                'ElseIf dato.ToUpper = "QUANTITY" AndAlso queFiCSV.ToUpper.EndsWith("LINEAL.CSV") = True Then
                                '    dato &= " (" & simLengthM & ")"
                            ElseIf dato.ToUpper.Contains("WEIGHT") = True Then
                                dato &= " (" & simPeso & ")"
                            ElseIf dato.ToUpper.EndsWith("LENGTH") OrElse dato.ToUpper.EndsWith("WIDTH") OrElse dato.ToUpper.EndsWith("HEIGHT") Then
                                dato &= " (" & simLength & ")"

                            End If
                            '
                            If x < lineaActual.Count - 1 Then
                                sb.AppendFormat("{0};", dato)
                            Else
                                ' No poner ; en la última columna
                                sb.AppendFormat("{0}", dato)
                            End If
                        Next
                        sb.AppendLine()
                        Continue While
                    End If
                    '
                    ' Esto ya serán datos (Guardar QUANTITY y WEIGHT para multiplicar en TOTAL_WEIGHT)
                    ' La columna 2, QUANTITY(1) llevará la cantidad (m2 o m en _PART, _AREA y _LINEAL respectivamente)
                    ' La columna 4, WEIGHT (3) llevará el peso unitario en _PART, _AREA y _LINEAL.
                    ' La columna 5, TOTAL_WEIGHT (4) llevará el peso total _PART, _AREA y _LINEAL.
                    Dim quantity As Double = 0
                    Dim weight As Double = 0
                    Dim total_weight As Double = 0
                    '
                    For x = 0 To lineaActual.Count - 1
                        Dim dato As String = lineaActual(x)
                        '
                        Dim valores As String() = dato.Split(" "c)
                        '' Esto será un número con unidades
                        If valores.Count = 2 AndAlso (IsNumeric(valores(0).Chars(0)) AndAlso IsNumeric(valores(1)) = False) Then
                            dato = valores(0)
                            If dato.Contains(".") AndAlso _sepdecimal <> "." Then
                                dato = dato.Replace(".", _sepdecimal)
                            ElseIf dato.Contains(",") AndAlso _sepdecimal <> "," Then
                                dato = dato.Replace(",", _sepdecimal)
                            End If
                        ElseIf IsNumeric(dato) Then ' valores.Count = 1 AndAlso IsNumeric(valores(0).Chars(0)) Then
                            dato = valores(0)
                            If dato.Contains(".") AndAlso _sepdecimal <> "." Then
                                dato = dato.Replace(".", _sepdecimal)
                            ElseIf dato.Contains(",") AndAlso _sepdecimal <> "," Then
                                dato = dato.Replace(",", _sepdecimal)
                            End If
                        End If
                        ' ** Quitaremos esto cuando ya se calculen en REVIT
                        ' Calcularemos el total. Si no va ya calculado en la Tabla de Planificación.
                        ' Ahora no va calculado al no poder multiplicar M2 o M con WEIGHT (Que va en kilos)
                        ' Solo en PARTS, AREA y LINEAL (Aunque PARTS ya lo lleva calculado
                        'If queFiCSV.ToUpper.EndsWith("PARTS.CSV") = True OrElse queFiCSV.ToUpper.EndsWith("AREA.CSV") = True OrElse queFiCSV.ToUpper.EndsWith("LINEAL.CSV") = True Then
                        '    If x = 1 AndAlso IsNumeric(dato) Then
                        '        quantity = CDbl(dato.Replace(",", "."))     ' Poner con . para hacer los cálculos
                        '    ElseIf x = 3 AndAlso IsNumeric(dato) Then
                        '        weight = CDbl(dato.Replace(",", "."))       ' Poner con . para hacer los cálculos
                        '    ElseIf x = 4 AndAlso quantity > 0 And weight > 0 Then
                        '        total_weight = Math.Round(quantity * weight, 3)    ' Con redondeo a 3 decimales
                        '        'total_weight = quantity * weight                    ' Sin redondear
                        '        '
                        '        ' Calcular y poner total_weight en el fichero CSV con el separador correcto.
                        '        If total_weight.ToString.Contains(".") AndAlso _sepdecimal <> "." Then
                        '            dato = total_weight.ToString.Replace(".", _sepdecimal)
                        '        ElseIf dato.Contains(",") AndAlso _sepdecimal <> "," Then
                        '            dato = total_weight.ToString.Replace(",", _sepdecimal)
                        '        End If
                        '    End If
                        'End If
                        '
                        If x < lineaActual.Count - 1 Then
                            ' Poner ; como separador del siguiente valor
                            sb.AppendFormat("{0};", dato)
                        Else
                            ' No poner ; en la última columna
                            sb.AppendFormat("{0}", dato)
                        End If
                    Next
                    sb.AppendLine()
                Catch ex As MalformedLineException
                    MsgBox("La línea actual " & ex.Message & " no es válida.")
                End Try
            End While
        End Using
        ''
        '' Borrar el fichero actual y volver a crearlo con el texto del StringBuilder.
        Try
            IO.File.Delete(queFiCSV)
            IO.File.WriteAllText(queFiCSV, sb.ToString, System.Text.Encoding.UTF8)
        Catch ex As Exception
            '' Ha dado error al borrarlo. No hacemos nada.
        End Try
    End Sub
End Module
'