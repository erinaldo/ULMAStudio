﻿Imports System.Reflection
Public Class AddIns
    Public lFullPaths As List(Of String)
    Private _VersionOld As String
    Private _VersionNew As String

    Public Sub New(queDll As String)
        lFullPaths = New List(Of String)
        Try
            Dim a As Assembly = System.Reflection.Assembly.LoadFile(queDll)
            Dim aInf As New Microsoft.VisualBasic.ApplicationServices.AssemblyInfo(a)
            Dim FullPath As String = a.Location
            If lFullPaths.Contains(FullPath) = False Then
                lFullPaths.Add(FullPath)
            End If
            Name = aInf.AssemblyName 'IO.Path.GetFileName(Me.FullName)
            VersionOld = aInf.Version.ToString
            a = Nothing
            aInf = Nothing
        Catch ex As Exception

        End Try
    End Sub

    Public Property Name As String

    Public Property VersionOld As String
        Get
            Return _VersionOld
        End Get
        Set
            If _VersionOld = "" Then
                _VersionOld = Value
            ElseIf Value < _VersionOld Then
                _VersionOld = Value
            End If
        End Set
    End Property
    Public Property VersionNew As String
        Get
            Return _VersionNew
        End Get
        Set
            Dim partes() As String = Value.Split("·"c)
            If partes.Count = 2 Then
                _VersionNew = partes(1)
                If VersionOld = _VersionNew Then
                    Me.Status = StatusEnum.UPDATED
                    Me.StatusImg = My.Resources.Updated32
                Else
                    Me.Status = StatusEnum.TOUPDATE
                    Me.StatusImg = My.Resources.ToUpdate32
                End If
            End If
        End Set
    End Property

    Public Property Status As StatusEnum
    Public Property StatusImg As System.Drawing.Image

    Public Overrides Function ToString() As String
        Dim mensaje As String = ""
        If Me.Name <> "" Then
            mensaje &= "Name = " & Me.Name & vbCrLf
            mensaje &= "Version Old = " & Me.VersionOld & vbCrLf
            mensaje &= "Version New = " & Me.VersionNew & vbCrLf
            mensaje &= "FullPaths :" & vbCrLf & String.Join(vbCrLf, lFullPaths.ToArray) & vbCrLf
        End If
        Return mensaje
    End Function
End Class

Public Enum StatusEnum
    UPDATED     ' Actualizado
    TOUPDATE    ' Actualizar
End Enum
