#Region "Imported Namespaces"
Imports System.Collections.Generic
Imports System.Diagnostics '� used for debug 
Imports System.IO '� used for reading folders 
Imports System.Windows
Imports System.Windows.Media.Imaging '� used for bitmap images 
Imports Autodesk.Revit.DB.Events
Imports adWin = Autodesk.Windows
Imports System.Timers
Imports RUI = Autodesk.Revit.UI
#End Region

<Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)>
<Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)>
Class UpdaterAddinApplication
    Implements IExternalApplication
    ''' <summary>
    ''' This method is called when Revit starts up before a 
    ''' document or default template is actually loaded.
    ''' </summary>
    ''' <param name="app">An object passed to the external 
    ''' application which contains the controlled application.</param>
    ''' <returns>Return the status of the external application. 
    ''' A result of Succeeded means that the external application started successfully. 
    ''' Cancelled can be used to signify a problem. If so, Revit informs the user that 
    ''' the external application failed to load and releases the internal reference.
    ''' </returns>
    Public Function OnStartup(
      ByVal app As UIControlledApplication) _
    As Result Implements IExternalApplication.OnStartup

        'TODO: Add your code here
        evRevit.evAppUIC = app
        evRevit.evAppC = app.ControlledApplication
        'AddHandler app.Idling, AddressOf evRevit.evAppCUI_Idling_LlenaObjectos
        'AddHandler app.Idling, AddressOf evRevit.evAppCUI_Idling
        'AddHandler Autodesk.Windows.ComponentManager.PreviewExecute, AddressOf evRevit.evCompM_PreviewExecute
        'EventoParametrosEscribeEnFamiliasdocumento = RUI.ExternalEvent.Create(New ExternalEvents.ParametrosEscribreEnFamiliasDocumento)
        'EventoFormCodify = RUI.ExternalEvent.Create(New ExternalEvents.FormCodify)
        CLog = New ULMALGFree.clsLogsCSV(System.Reflection.Assembly.GetExecutingAssembly)   ', app.ControlledApplication.VersionNumber.Substring(0, 4))
        'CLog._appyear = app.ControlledApplication.VersionNumber.Substring(0, 4)
        '
        'ULMALGFree.clsLogsCSV._ItHasUpdate = False
        '
        ' 1.- ***** Cargar datos del fichero .INI
        Dim resultado() As String = modVar.INICargar()
        Dim errores As String = resultado(0)
        ''PonLog("***** Iniciamos Revit *****")
        ''PonLog("***** VALORES FICHERO .INI *****" & vbCrLf & resultado(1) & vbCrLf & StrDup(50, "*"))
        If errores <> "" Then
            ''PonLog(vbCrLf & errores)
            TaskDialog.Show("ATTENTION", "Error in " & My.Application.Info.AssemblyName & ".ini" & vbCrLf & errores)
            Return Result.Failed
            Exit Function
        End If
        '
        'If log Then PonLog_BASICO(ULMALGFree.clsLogsCSV._appFicherologBASE, "Start REVIT")
        'If CLog IsNot Nothing Then CLog.PonLog_ULMA(ULMALGFree.ACTION.OPEN_REVIT,,, arrM123, arrL123)
        'If CLog IsNot Nothing Then CLog.PonLog_ULMA("XMLs VERSION", NOTES:=dateXML.ToString)
        ' 4.- ***** Creamos el interface (Ribbon, Paneles y botones)
        ''PonLog("Cargar RibbonTab, RibbonPanels y RibbonButtons")
        'Ribbon_ADD_ULMA(app)
        '
        'Must return some code
        Return Result.Succeeded
    End Function

    ''' <summary>
    ''' This method is called when Revit is about to exit.
    ''' All documents are closed before this method is called.
    ''' </summary>
    ''' <param name="app">An object passed to the external 
    ''' application which contains the controlled application.</param>
    ''' <returns>Return the status of the external application. 
    ''' A result of Succeeded means that the external application successfully shutdown. 
    ''' Cancelled can be used to signify that the user cancelled the external operation 
    ''' at some point. If false is returned then the Revit user should be warned of the 
    ''' failure of the external application to shut down correctly.</returns>
    Public Function OnShutdown(
      ByVal app As UIControlledApplication) _
    As Result Implements IExternalApplication.OnShutdown

        'TODO: Add your code here
        Return Result.Succeeded
    End Function
    '
#Region "RIBBON"

    Sub Ribbon_ADD_ULMA(ByVal app As UIControlledApplication)
        '' 1.- Crear el RibbonTab
        Try
            app.CreateRibbonTab(_uiLabName)
        Catch ex As Exception
            ' Por si ya exist�a _uiLabName = ULMA
            Try
                _uiLabName = _uiLabName1
                app.CreateRibbonTab(_uiLabName)
            Catch ex1 As Exception
                Exit Sub
            End Try
        End Try
        ''
        '' 2.- Crear el RibbonPanel (Utilidades)
        panelUpdater = app.CreateRibbonPanel(_uiLabName, nombrePaneUpdater)      ' Updater
        'panelPruebas = app.CreateRibbonPanel(_uiLabName, nombrePanelPruebas)       '' Pruebas
        '
        ' 3.- Llenar los objetos adWin.RibbonPanel
        modULMA.RibbonPanelULMALlena()
        ' 4.- A�adir Botones al cada RibbonPanel
        ' Botones de Help/About (Help + About)
        PushButtons_Add_UPDATER(panelUpdater)
        'panelUpdater.AddSeparator()
        ' 5.- A�adir otros botones de ALBERTO
        'PushButtons_Add_ABOUT(panelUpdater)
        'If My.Computer.Name.ToUpper = "ALBERTO-HP" Or Environment.UserDomainName.ToUpper.Contains("ADA") Then
        '    '' Nombre de usuario con "Environment.UserName"
        '    AddPushButtonLISTARIBBONS(panelConf)
        'End If
    End Sub
    '
    ''' <summary>
    ''' Ejemplo de boton para comando de Revit existente
    ''' </summary>
    ''' <param name="panel"></param>
    Sub PushButtons_Add_LOADFAMILY(ByVal panel As RibbonPanel)
        '' ***** BOTON ID_FAMILY_LOAD (De Revit)
        Dim oRi As adWin.RibbonItem = modRibbons.RibbonItem_BuscaDame("Insert", "load_from_library_shr", "ID_FAMILY_LOAD")
        If oRi IsNot Nothing Then
            panelUpdaterW.Source.Items.Add(oRi)
        End If
    End Sub
    '
    ''' <summary>
    ''' Bot�n ULMARevitUpdater
    ''' </summary>
    ''' <param name="panel"></param>
    Sub PushButtons_Add_UPDATER(ByVal panel As RibbonPanel)
        ''
        Dim btnRibbonBotonData As PushButtonData
        Dim queImg As System.Windows.Media.Imaging.BitmapSource
        ''
        '' ***** BOTON LISTADOS
        btnRibbonBotonData = New PushButtonData("Updater", "Updater", _IntroLabFullPath, _IntroLabName & ".btnUpdater")
        ' Disponible en ZeroDocPanel
        btnRibbonBotonData.AvailabilityClassName = _IntroLabName & ".ZeroDocState"
        ' Add a button to the panel 
        btnUpdaterBoton = CType(panel.AddItem(btnRibbonBotonData), PushButton)
        ' Add an icon 
        ' Make sure you reference WindowsBase and PresentationCore, 
        ' and import System.Windows.Media.Imaging namespace.
        If hayupdates Then
            queImg = DameImagenRecurso(My.Resources.logoulmau32.GetHbitmap()) '' NewBitmapImage("bomUnion.png")
        Else
            queImg = DameImagenRecurso(My.Resources.logoulma32.GetHbitmap()) '' NewBitmapImage("bomUnion.png")
        End If
        btnUpdaterBoton.Image = queImg
        btnUpdaterBoton.LargeImage = queImg
        ' Add a tooltip
        btnUpdaterBoton.ToolTip = "ULMA AddIns Updater"
        btnUpdaterBoton.LongDescription = "ULMA AddIns Updater v" & My.Application.Info.Version.ToString
        btnUpdaterBoton.Enabled = True    '' Hasta que pasemos por Options
    End Sub
    '
    Public Sub BotonULMAEjecuta(nombrePanel As String, nombreBoton As String, Optional nombreRibbon As String = _IntroLabName)
        ''
        '' ************** Ejecutar el boton Options de ULMA
        Dim comOpti As String = "CustomCtrl_%CustomCtrl_%" &
            nombreRibbon &
            "%" & nombrePanel &
            "%" & nombreBoton
        Dim queId As RevitCommandId = RevitCommandId.LookupCommandId(comOpti)
        evRevit.evAppUI.PostCommand(queId)
    End Sub
#End Region
End Class
