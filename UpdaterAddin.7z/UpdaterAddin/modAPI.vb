﻿Imports System.Runtime.InteropServices
'Imports Inventor

Module modAPI
    'SHARED SI ESTAMOS EN UNA CLASE "PUBLIC SHARED", PARA QUE NO HAGA FALTA INSTANCIAR LA CLASE 
    'Private Declare Function SetParent Lib "user32" Alias "SetParent" (ByVal hWndChild As Int32, ByVal hWndNewParent As Int32) As Int32
    ''
    '' Funciones para ToolTip sobre ListBox
    Public Const LB_GETCURSEL = &H188

    Public Declare Function LBItemFromPt Lib "COMCTL32.DLL" _
    (ByVal hLB As Integer, ByVal ptX As Integer, ByVal ptY As Integer,
    ByVal bAutoScroll As Integer) As Integer

    Public Declare Function SendMessage Lib "user32" Alias _
    "SendMessageA" (ByVal hwnd As Integer, ByVal wMsg As Integer,
    ByVal wParam As Integer, ByVal lParam As Integer) As Integer

    <System.Runtime.InteropServices.DllImport("user32.DLL", SetLastError:=True)> _
    Public Function SetParent( _
    ByVal hWndChild As Int32, ByVal hWndNewParent As Int32) As Int32
    End Function

    '<System.Runtime.InteropServices.DllImport("user32.DLL", SetLastError:=True)> _
    'Public Function SendMessage( _
    ' ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, _
    ' ByVal wParam As Integer, ByVal lParam As Integer _
    ' ) As Integer
    'End Function

    <System.Runtime.InteropServices.DllImport("user32.DLL", SetLastError:=True)> _
    Public Function FindWindow( _
     ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr
        '' Podemos poner Nothing en lpClassName (modAPI.FindWindow(Nothing, [Titulo ventana])
    End Function

    <System.Runtime.InteropServices.DllImport("user32.DLL", SetLastError:=True)> _
    Public Function FindWindowEx( _
        hwndParent As IntPtr, hwndChildAfter As IntPtr, lpszClass As String, lpszWindow As String) As IntPtr
    End Function

    <System.Runtime.InteropServices.DllImport("user32.DLL", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Public Function SetWindowText( _
     ByVal hWnd As System.IntPtr, ByVal lpString As String) As IntPtr
        '' Podemos poner Nothing en lpClassName (modAPI.FindWindow(Nothing, [Titulo ventana])
    End Function

    <System.Runtime.InteropServices.DllImport("user32.DLL", SetLastError:=True)> _
    Public Function SetForegroundWindow( _
     ByVal hWnd As IntPtr) As Boolean
    End Function

    ' 64-bit version
    'Public Declare Sub PtrSafe Sleep Lib "kernel32" (ByVal dwMilliseconds As LongLong)

    ' 32-bit version
    Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)


    ' Para mostrar una ventana según el handle (hwnd)
    ' ShowWindow() Commands
    Public Enum eShowWindow As Long
        HIDE_eSW = 0&
        SHOWNORMAL_eSW = 1&
        NORMAL_eSW = 1&
        SHOWMINIMIZED_eSW = 2&
        SHOWMAXIMIZED_eSW = 3&
        MAXIMIZE_eSW = 3&
        SHOWNOACTIVATE_eSW = 4&
        SHOW_eSW = 5&
        MINIMIZE_eSW = 6&
        SHOWMINNOACTIVE_eSW = 7&
        SHOWNA_eSW = 8&
        RESTORE_eSW = 9&
        SHOWDEFAULT_eSW = 10&
        MAX_eSW = 10&
    End Enum
End Module
