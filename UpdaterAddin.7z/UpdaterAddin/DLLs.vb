﻿Public Class DLLs
    Public Shared t As String = vbTab
    Public Shared ReadOnly DirIni As String() =
        {"C:\ProgramData\Autodesk\Revit\Addins",
        "C:\Program Files\2aCAD\Revit\ULMARevitUpdater",
        Environment.GetEnvironmentVariable("USERPROFILE") & "\AppData\Roaming\Autodesk\Revit\Addins"}
    Public Shared soloDirIni As Boolean = True
    Public Shared lDlls As Dictionary(Of String, AddIns)

    Public Shared Function DLLs_Listar() As String
        Dim mensaje As String = ""
        lDlls = New Dictionary(Of String, AddIns)
        For Each Folder As String In DirIni '.AsParallel
            If IO.Directory.Exists(Folder) = False Then Continue For
            DLL_Listar_Recursivo(Folder)
            Try
                For Each oFol As String In IO.Directory.GetDirectories(Folder, "*.*", IO.SearchOption.AllDirectories)
                    Try
                        DLL_Listar_Recursivo(oFol)
                    Catch ex As Exception
                        Continue For
                    End Try
                Next
            Catch ex As Exception
                Continue For
            End Try

        Next
        '
        For Each key As String In lDlls.Keys
            Dim oDll As AddIns = lDlls(key)
            mensaje &= oDll.ToString
            mensaje &= StrDup(80, "*") & vbCrLf
        Next
        Updates_Buscar()
        Return mensaje
    End Function

    Public Shared Sub DLL_Listar_Recursivo(oFol As String)
        For Each DllPath As String In IO.Directory.GetFiles(oFol, "*.dll", IO.SearchOption.TopDirectoryOnly)
            Dim soloNombre As String = IO.Path.GetFileNameWithoutExtension(DllPath)
            Dim encontrado As Boolean = False
            For Each mask As String In maskaddins
                mask = mask.Replace("*", "")
                If soloNombre.ToUpper.StartsWith(mask.ToUpper) Then
                    encontrado = True
                    Exit For
                End If
            Next
            If encontrado = False Then Continue For

            Dim oAddIn As AddIns = New AddIns(DllPath)
            If lDlls.ContainsKey(oAddIn.Name) Then
                lDlls(oAddIn.Name).VersionOld = oAddIn.VersionOld
                lDlls(oAddIn.Name).lFullPaths.Add(DllPath)
            Else
                lDlls.Add(oAddIn.Name, New AddIns(DllPath))
            End If
            oAddIn = Nothing
        Next
    End Sub

    Public Shared Sub Updates_Buscar()
        For Each queFi As String In IO.Directory.GetFiles(_dirUpdates, "*.zip")
            Dim NombreFull As String = IO.Path.GetFileNameWithoutExtension(queFi)
            Dim partes() As String = NombreFull.Split("·"c)
            Dim nombre As String = partes(0)
            Dim version As String = IIf(partes.Count = 2, partes(1), "").ToString
            If lDlls.ContainsKey(nombre) Then
                lDlls(nombre).VersionNew = NombreFull
            End If
        Next
    End Sub
End Class
