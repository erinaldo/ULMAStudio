﻿Imports System.Collections
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.IO
Imports System.Linq
Imports System.Reflection
Imports System.Text
Imports System.Windows
Imports System.Windows.Forms
Imports System.Windows.Media.Imaging
Imports System.Xml
Imports Autodesk.Revit.ApplicationServices
'Imports Autodesk.Revit.Utility
Imports Autodesk.Revit.ApplicationServices.Application
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.DB.Architecture
Imports Autodesk.Revit.DB.Document
Imports Autodesk.Revit.DB.Electrical
Imports Autodesk.Revit.DB.Events
Imports Autodesk.Revit.DB.Mechanical
Imports Autodesk.Revit.DB.Plumbing
Imports Autodesk.Revit.DB.Structure
'Imports Autodesk.Revit.Collections
Imports Autodesk.Revit.Exceptions
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Events
Imports Autodesk.Revit.UI.Selection

Partial Public Class evRevit
#Region "EVENTOS UIAPPLICATION"
    Private Shared Sub evAppCUI_ApplicationClosing(sender As Object, e As ApplicationClosingEventArgs) Handles evAppUIC.ApplicationClosing
        'System.Windows.MessageBox.Show("UIControlledApplication.ApplicationClosing")
        'PonLog("***** Salimos de Revit *****" & vbCrLf & vbCrLf)
        If evApp IsNot Nothing Then
            UnsubscribeAll()
        End If
        ' Log, subir y borrar ficheros antes de salir.
        'ULMALGFree.clsLogsCSV._ultimaApp = ULMALGFree.queApp.UCREVIT
        'If CLog IsNot Nothing Then CLog.PonLog_ULMA(ULMALGFree.ACTION.CLOSE_REVIT)
        'If log Then PonLog_BASICO(ULMALGFree.clsLogsCSV._appFicherologBASE, "End REVIT")
        'Try
        '    If CLog IsNot Nothing Then Call CLog.CompruebaConexionFTPUlma(True, False, True)
        'Catch ex As Exception
        '    Debug.Print(ex.ToString)
        'End Try
        'While CLog.terminado = False
        '    System.Windows.Forms.Application.DoEvents()
        '     Quedarse aquí hast aque termine todo. Para que no salga de Revit.
        'End While
    End Sub
    Private Shared Sub evAppCUI_DialogBoxShowing(sender As Object, e As DialogBoxShowingEventArgs) Handles evAppUIC.DialogBoxShowing
        'System.Windows.MessageBox.Show("UIControlledApplication.DialogBoxShowing-->Iniciado")
    End Sub
    Public Shared Sub evAppCUI_Idling_LlenaObjectos(sender As Object, e As IdlingEventArgs)
        RemoveHandler evAppUIC.Idling, AddressOf evAppCUI_Idling_LlenaObjectos
        If evAppUI Is Nothing Then evAppUI = TryCast(sender, UIApplication)
        If evApp Is Nothing AndAlso evAppUI IsNot Nothing Then evApp = evAppUI.Application
        'evAppUI = TryCast(sender, UIApplication)
        'evApp = evAppUI.Application
    End Sub

    Public Shared Sub evAppCUI_Idling(sender As Object, e As IdlingEventArgs) Handles evAppUIC.Idling
        'System.Windows.MessageBox.Show("UIControlledApplication.Idling-->Iniciado")
        'evApp.PurgeReleasedAPIObjects()
    End Sub
    Private Shared Sub evAppCUI_ViewActivated(sender As Object, e As ViewActivatedEventArgs) Handles evAppUIC.ViewActivated
        'System.Windows.MessageBox.Show("UIControlledApplication.ViewActivated")
    End Sub
    Private Shared Sub evAppCUI_ViewActivating(sender As Object, e As ViewActivatingEventArgs) Handles evAppUIC.ViewActivating
        'System.Windows.MessageBox.Show("UIControlledApplication.ViewActivating")
        'SubscribeToDoc(e.Document)
    End Sub
#End Region
    '
#Region "EVENTOS UIAPPLICATION DESACTIVADOS"
    Private Shared Sub evAppCUI_DisplayingOptionsDialog(sender As Object, e As DisplayingOptionsDialogEventArgs) Handles evAppUIC.DisplayingOptionsDialog
        'System.Windows.MessageBox.Show("UIControlledApplication.DisplayingOptionsDialog-->Iniciado")
    End Sub

    Private Shared Sub evAppCUI_DockableFrameFocusChanged(sender As Object, e As DockableFrameFocusChangedEventArgs) Handles evAppUIC.DockableFrameFocusChanged
        'System.Windows.MessageBox.Show("UIControlledApplication.DockableFrameFocusChanged-->Iniciado")
    End Sub

    Private Shared Sub evAppCUI_DockableFrameVisibilityChanged(sender As Object, e As DockableFrameVisibilityChangedEventArgs) Handles evAppUIC.DockableFrameVisibilityChanged
        'System.Windows.MessageBox.Show("UIControlledApplication.DockableFrameVisibilityChanged-->Iniciado")
    End Sub

    Private Shared Sub evAppCUI_FabricationPartBrowserChanged(sender As Object, e As FabricationPartBrowserChangedEventArgs) Handles evAppUIC.FabricationPartBrowserChanged
        'System.Windows.MessageBox.Show("UIControlledApplication.FabricationPartBrowserChanged-->Iniciado")
    End Sub
    Private Shared Sub evAppCUI_TransferredProjectStandards(sender As Object, e As TransferredProjectStandardsEventArgs) Handles evAppUIC.TransferredProjectStandards
        'System.Windows.MessageBox.Show("UIControlledApplication.TransferredProjectStandards-->Iniciado")
    End Sub

    Private Shared Sub evAppCUI_TransferringProjectStandards(sender As Object, e As TransferringProjectStandardsEventArgs) Handles evAppUIC.TransferringProjectStandards
        'System.Windows.MessageBox.Show("UIControlledApplication.TransferringProjectStandards-->Iniciado")
    End Sub
#End Region
End Class
