#Region "Imported Namespaces"
Imports System
Imports System.Collections.Generic
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection
#End Region

<Transaction(TransactionMode.Manual)>
Public Class btnUpdater
    Implements Autodesk.Revit.UI.IExternalCommand

    ''' <summary>
    ''' The one and only method required by the IExternalCommand interface, the main entry point for every external command.
    ''' </summary>
    ''' <param name="commandData">Input argument providing access to the Revit application, its documents and their properties.</param>
    ''' <param name="message">Return argument to display a message to the user in case of error if Result is not Succeeded.</param>
    ''' <param name="elements">Return argument to highlight elements on the graphics screen if Result is not Succeeded.</param>
    ''' <returns>Cancelled, Failed or Succeeded Result code.</returns>
    Public Function Execute(
      ByVal commandData As ExternalCommandData,
      ByRef message As String,
      ByVal elements As ElementSet) _
    As Result Implements IExternalCommand.Execute
        'PonLog("btnHelp (Help)")
        ''
        '' Llenamos las variables que necesitemos.
        If evRevit.evAppUI Is Nothing Then evRevit.evAppUI = commandData.Application
        'TODO: Add your code here
        ULMALGFree.clsLogsCSV._ultimaApp = ULMALGFree.queApp.UCREVIT
        ''
        enejecucion = True
        Dim resultado As Result = Result.Succeeded
        ''
        ''
        frmU = New frmUpdater
        'If cLcsv IsNot Nothing Then cLcsv.PonLog_ULMA(ULMALGFree.ACTION.UCREVIT_HELP,,, arrM123, arrL123, ultimaTraduccion)
        ''
        ''
        If frmU.ShowDialog(New WindowWrapper(Process.GetCurrentProcess.MainWindowHandle)) = System.Windows.Forms.DialogResult.OK Then
            resultado = Result.Succeeded
        Else
            resultado = Result.Cancelled
        End If
        ''
        '' Vaciamos las variables
        'evRevit.evAppUI = Nothing
        'utApp1 = Nothing
        frmU = Nothing
        ''
        enejecucion = False
        Return resultado
    End Function
End Class
'End Namespace
