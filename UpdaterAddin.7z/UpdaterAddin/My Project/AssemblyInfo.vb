﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("UpdaterAddin")>
<Assembly: AssemblyDescription("UpdaterAddin UCRevitFree")>
<Assembly: AssemblyCompany("ULMA Construccion")>
<Assembly: AssemblyProduct("UpdaterAddin Visual Basic .NET Revit Add-in")>
<Assembly: AssemblyCopyright("Copyright (C) 2018 by Jose Alberto Torres Jaraute, 2aCAD Graitec Group")>
<Assembly: AssemblyTrademark("ULMARevitUpdater")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("9162C779-F1A2-4799-BE4A-D239E3F157A9")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("2019.0.0.1")>
<Assembly: AssemblyFileVersion("2019.0.0.1")>
