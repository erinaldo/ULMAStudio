﻿'Imports ConsultarBDI
Imports System.Windows.Forms
Imports adWin = Autodesk.Windows
Imports Autodesk.Revit.DB
Module modULMA
    ''
    Private Const categoryview As String = "VIEW TYPE"
    Public formHide As System.Windows.Forms.Form = Nothing
    Public compruebacambios As Boolean = False
    Public preInf As String = ""
    Public lstErrores As List(Of String)
    '
    Public Sub Cierra_DocumentosUlma(oApp As Autodesk.Revit.ApplicationServices.Application, Optional soloULMA As Boolean = True)
        If oApp.Documents.Size = 0 Then Exit Sub
        '
        Dim cerraractual As Boolean = False
        For Each queDoc As Autodesk.Revit.DB.Document In oApp.Documents
            Try
                If soloULMA Then
                    Dim colIds As List(Of ElementId) = utilesRevit.FamilySymbol_DameULMA_ID(queDoc, BuiltInCategory.OST_GenericModel)
                    If colIds IsNot Nothing AndAlso colIds.Count > 0 Then
                        If queDoc.PathName <> evRevit.evAppUI.ActiveUIDocument.Document.PathName Then
                            queDoc.Close(True)
                        Else
                            cerraractual = True
                        End If
                    End If
                    colIds = Nothing
                Else
                    If queDoc.PathName <> evRevit.evAppUI.ActiveUIDocument.Document.PathName Then
                        queDoc.Close(True)
                    Else
                        cerraractual = True
                    End If
                End If
            Catch ex As Exception
                Continue For
            End Try
        Next
        '
        If cerraractual Then
            Dim rvtIntPtr As IntPtr = Autodesk.Windows.ComponentManager.ApplicationWindow
            clsAPI.SetForegroundWindow(rvtIntPtr)
            Try
                clsAPI.keybd_event(CByte(clsAPI.eMensajes.VK_ESCAPE), 0, 0, UIntPtr.Zero)
                clsAPI.keybd_event(CByte(clsAPI.eMensajes.VK_ESCAPE), 0, 2, UIntPtr.Zero)
                clsAPI.keybd_event(CByte(clsAPI.eMensajes.VK_ESCAPE), 0, 0, UIntPtr.Zero)
                clsAPI.keybd_event(CByte(clsAPI.eMensajes.VK_ESCAPE), 0, 2, UIntPtr.Zero)
                System.Windows.Forms.SendKeys.SendWait("^{F4}")
                'System.Windows.Forms.SendKeys.SendWait("^W")
            Catch ex As Exception
                Debug.Print(ex.ToString)
            End Try
        End If
    End Sub
    '
    Public Enum NProp
        TYPE
        FAMILY_CODE
        ITEM_CODE
        ITEM_LENGTH
        ITEM_HEIGHT
        ITEM_WIDTH
        ITEM_WEIGHT
        ITEM_DESCRIPTION
        Count
        W_MARKET
        ITEM_GENERIC
    End Enum
    '
    Public Sub RibbonPanelULMALlena()
        Dim encontrado As Boolean = False
        Dim ribbon As adWin.RibbonControl = adWin.ComponentManager.Ribbon
        ''
        '' *** Primero llenamos todos los RibbonPanel de UCRevit2018
        For Each tab As adWin.RibbonTab In ribbon.Tabs
            '' Si no es el RIBBON de PrefaBIM, continuar
            If (tab.AutomationName <> _uiLabName) Then
                Continue For
            End If
            '' RIBBONPANNELS de cada Ribbontab
            For Each oPanel As adWin.RibbonPanel In tab.Panels
                Select Case oPanel.Source.AutomationName
                    Case nombrePaneUpdater    ' "Help/About"           '' Para botones Export BOM y Complete BOM
                        panelUpdaterW = oPanel
                        'Case nombrePanelPruebas ' "Pruebas"
                        '    panelPruebasW = oPanel
                End Select
            Next
        Next
    End Sub
    '
    Public Sub Cierra_Proceso(quePro As String)
        Dim arrProcesos() As Process = Process.GetProcessesByName(quePro)
        If arrProcesos IsNot Nothing AndAlso arrProcesos.Count > 1 Then
            For Each qPro As Process In arrProcesos
                qPro.Kill()
            Next
        End If
    End Sub
End Module
