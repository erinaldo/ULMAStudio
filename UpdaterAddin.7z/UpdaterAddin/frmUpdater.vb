﻿Imports System.Windows.Forms
Imports ULMALGFree.clsLogsCSV
Public Class frmUpdater
    Public lAddIns As List(Of AddIns)
    Private Sub FrmUpdater_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "ULMA - AddIns Updater" & " / " & My.Application.Info.Version.ToString
        DLLS_RellenaDatos()
    End Sub

    Private Sub frmUpdater_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        frmU = Nothing
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    '
    Public Sub DLLS_RellenaDatos()
        ' Rellenar lDlls
        Call DLLs.DLLs_Listar()
        ' Asignar Datasource
        'dgUpdates.DataSource = DLLs.lDlls.Values.ToList
        '
        ' Crear y asignar columnas
        Dim index As Integer = dgUpdates.Columns.Add("Name", "Name")
        dgUpdates.Columns.Item(index).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        index = dgUpdates.Columns.Add("VersionOld", "Old_Version")
        dgUpdates.Columns.Item(index).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        index = dgUpdates.Columns.Add("VersionNes", "New_Version")
        dgUpdates.Columns.Item(index).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        index = dgUpdates.Columns.Add("Update", "Update")
        dgUpdates.Columns.Item(index).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        dgUpdates.Columns.Item(index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        '
        For Each oAddins In DLLs.lDlls.Values
            If oAddins.VersionNew Is Nothing OrElse oAddins.VersionNew = "" Then Continue For
            If oAddins.VersionOld = oAddins.VersionNew Then Continue For
            '
            Dim x As Integer = dgUpdates.Rows.Add
            dgUpdates.Rows.Item(x).Tag = oAddins
            '
            Dim cName As New DataGridViewTextBoxCell
            cName.Value = oAddins.Name
            dgUpdates.Rows.Item(x).Cells.Item(0) = cName
            cName = Nothing
            '
            Dim cVersionOld As New DataGridViewTextBoxCell
            cVersionOld.Value = oAddins.VersionOld
            dgUpdates.Rows.Item(x).Cells.Item(1) = cVersionOld
            cVersionOld = Nothing
            '
            Dim cVersionNew As New DataGridViewTextBoxCell
            cVersionNew.Value = oAddins.VersionNew
            cVersionNew.Style.ForeColor = System.Drawing.Color.Red
            'cVersionNew.Style.Font = New Drawing.Font(cVersionNew.Style.Font, Drawing.FontStyle.Bold)
            dgUpdates.Rows.Item(x).Cells.Item(2) = cVersionNew
            cVersionNew = Nothing
            '
            Dim cCheck As New DataGridViewCheckBoxCell
            cCheck.Value = True
            dgUpdates.Rows.Item(x).Cells.Item(3) = cCheck
            cCheck = Nothing
        Next
        For Each oCol As DataGridViewColumn In dgUpdates.Columns
            oCol.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        Next
        dgUpdates.Update()
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Aquí ejecutaremos la actualización


        '
        Me.Close()
    End Sub

    Private Sub DgUpdates_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgUpdates.CellContentClick
        Dim Grid As DataGridView = CType(sender, DataGridView)
        If TypeOf Grid.Rows.Item(e.RowIndex).Cells.Item(e.ColumnIndex) Is DataGridViewCheckBoxCell Then
            Dim value As Boolean = CBool(Grid.Rows.Item(e.RowIndex).Cells.Item(e.ColumnIndex).Value)
            Grid.Rows.Item(e.RowIndex).Cells.Item(e.ColumnIndex).Value = Not (value)
            Dim hayactivos As Boolean = False
            For x As Integer = 0 To Grid.Rows.Count - 1
                If CBool(Grid.Rows.Item(x).Cells.Item(e.ColumnIndex).Value) = True Then
                    hayactivos = True
                    Exit For
                End If
            Next
            btnUpdate.Enabled = hayactivos
        End If
    End Sub
End Class