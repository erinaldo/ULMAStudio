﻿Public Class ZeroDocState
    Implements IExternalCommandAvailability

    Public Function IsCommandAvailable(applicationData As UIApplication, selectedCategories As CategorySet) As Boolean Implements IExternalCommandAvailability.IsCommandAvailable
        Return True
    End Function
End Class
