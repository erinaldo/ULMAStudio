﻿Imports System
Imports System.IO
'Imports ConsultarBDI
''
Module modVar
    ' ***** Objetos Revit
    Public queTr As Transaction = Nothing
    Public queTrSub As SubTransaction = Nothing
    Public activeSketchPlane3D As SketchPlane = Nothing
    Public activeViewOrientation3D As ViewOrientation3D = Nothing
    Public activeOptId As ElementId = ElementId.InvalidElementId
    Public Const typeAnnotationSymbol As Autodesk.Revit.DB.BuiltInCategory = BuiltInCategory.OST_GenericAnnotation
    Public Const typeFamily As Autodesk.Revit.DB.BuiltInCategory = BuiltInCategory.OST_GenericModel 'BuiltInCategory.OST_Site
    Public Const typeSet As Autodesk.Revit.DB.BuiltInCategory = BuiltInCategory.OST_GenericModel

    '
    ' ***** CLASES
    Public CIni As ULMALGFree.clsINI
    Public CLog As ULMALGFree.clsLogsCSV
    '
    ' ***** RibbonPanels y PushButtons
    ' RibbonPanel
    Public panelUpdater As RibbonPanel
    Public panelUpdaterW As Autodesk.Windows.RibbonPanel
    ' PushButton
    Public btnUpdaterBoton As PushButton
    '
    ' ***** FORMULARIOS
    Public frmU As frmUpdater = Nothing
    '
    ' ***** CONSTANTES
    Public _uiLabName As String = "ULMA"          ' Nombre Ribbon "ULMA"
    Public Const _uiLabName1 As String = "ULMAF"          ' Nombre Ribbon "ULMAF"
    Public Const fabricante As String = "ULMA"
    Public Const RevitVersion As String = "2018"                ' Versión de Revit en la que va el desarrollo
    Public Const _dllExtension As String = ".dll"
    Public Const _IntroLabName As String = "UpdaterAddIn"
    Public Const _UCRevitFree As String = "UCRevitFree"
    Public ReadOnly tab As Char = Chr(9)
    Public Const comi As String = """" '& Chr(34)
    '
    ' ***** COLECCIONES
    '
    ' ***** VARIABLES
    Public _IntroLabFullPath As String = System.Reflection.Assembly.GetExecutingAssembly.Location
    Public _dirApp As String = Path.GetDirectoryName(_IntroLabFullPath)      ' Directorio de instalación de la DLL.
    Public _dirUpdates As String = IO.Path.Combine(_dirApp, "UPDATES")
    Public _fileIni As String = IO.Path.Combine(_dirApp, My.Application.Info.AssemblyName & ".ini")
    Public _fileIniFree As String = IO.Path.Combine(_dirApp, _UCRevitFree & ".ini")
    Public _sepdecimal As String = System.Globalization.CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalSeparator
    Public _sepmiles As String = System.Globalization.CultureInfo.CurrentCulture.NumberFormat.CurrencyGroupSeparator
    Public _introLabPath As String = Path.Combine(_dirApp, _IntroLabName + _dllExtension)
    Public enejecucion As Boolean = False
    '
    ' ***** VARIABLES fichero .INI
    Public log As Boolean = True
    Public maskaddins As List(Of String)
    Public hayupdates As Boolean = True

    Public Function INICargar() As String()
        If CIni Is Nothing Then CIni = New ULMALGFree.clsINI
        Dim mensaje(1) As String
        '' Mensaje(0) contendrá los errores.
        '' mensaje(1) contendrá los valores leidos del .INI
        mensaje(0) = "" : mensaje(1) = ""
        '
        '[OPTIONS]
        'log=1
        'addins=ULMARevitUpdater,UCRevit*,UCBrowser,ULMALGFree.      '* para que localice todas las versiones
        '
        ' log
        Dim logtemp As String = CIni.IniGet(_fileIni, "OPTIONS", "log")
        If logtemp = "0" Then log = False
        mensaje(1) &= "log = " & log.ToString & vbCrLf
        '
        ' addins
        maskaddins = New List(Of String)
        Dim addinstemp As String = CIni.IniGet(_fileIni, "OPTIONS", "maskaddins")
        If addinstemp <> "" Then
            Dim partes() As String = addinstemp.Split(","c)
            For Each mask As String In partes
                maskaddins.Add(mask)
            Next
        End If
        mensaje(1) &= "maskaddins = " & String.Join(",", maskaddins.ToArray) & vbCrLf
        '
        INICargar = mensaje
    End Function
    '
    Public Sub AddIns_Rellena(ByRef lAddIns As List(Of AddIns))

    End Sub
    Public Function DameCaminoAbsolutoUsuarioFichero(quePathFi As String) As String
        Dim resultado As String = quePathFi
        ''
        'Dim appdata As String = Environment.GetEnvironmentVariable("APPDATA")
        'Dim userprofile As String = Environment.GetEnvironmentVariable("USERPROFILE")
        ''
        '' Solo cambiamos el valor si se cumplen estos criterios.
        '' Si no se cumplen, devolvemos el mismo valor que tenía. Para evaluarlo posteriormente.
        If quePathFi.ToUpper.StartsWith("%USERPROFILE%") Then
            resultado = quePathFi.Replace("%USERPROFILE%", _dirApp)
        ElseIf quePathFi.ToUpper.StartsWith("%APPDATA%") Then
            resultado = quePathFi.Replace("%APPDATA%", _dirApp)
        ElseIf quePathFi.StartsWith(".\") Then
            resultado = quePathFi.Replace(".\", _dirApp & "\")
        ElseIf quePathFi.StartsWith("..\") Then
            resultado = _dirApp & IO.Path.DirectorySeparatorChar & quePathFi
            resultado = IO.Path.GetFullPath(resultado)
        ElseIf quePathFi.StartsWith("\\") OrElse quePathFi.Contains(":") Then
            resultado = quePathFi
        ElseIf quePathFi = "" Then
            resultado = quePathFi
        ElseIf quePathFi <> "" Then
            resultado = IO.Path.Combine(_dirApp, quePathFi)
        End If
        '' Otra comprobación, por seguridad
        'If IO.Directory.Exists(IO.Path.GetDirectoryName(resultado)) = False OrElse resultado = "" Then
        'resultado = IO.Path.Combine(_dirApp, resultado)
        'End If
        ''
        Return resultado
    End Function
    ''
    Public Function FormDameControl(ByRef queform As System.Windows.Forms.Form, queNombre As String) As System.Windows.Forms.Control
        Dim resultado As System.Windows.Forms.Control = Nothing
        ''
        Dim encontrado As Boolean = False
        For Each queC As System.Windows.Forms.Control In queform.Controls
            If queC.Name = queNombre Then
                resultado = queC
                Exit For
            End If
            ''
            For Each queC1 As System.Windows.Forms.Control In queC.Controls
                If queC1.Name = queNombre Then
                    resultado = queC1
                    encontrado = True
                    Exit For
                End If
            Next
            If encontrado = True Then Exit For
        Next
        ''
        Return resultado
    End Function
    '
    Public Sub BotonesAplicacionEstado(activar As Boolean)
        If btnUpdaterBoton IsNot Nothing Then btnUpdaterBoton.Enabled = activar
    End Sub
    Public Function FormulariosDesarrolloAbiertos() As Boolean
        '' ***** FORMULARIOS
        If frmU IsNot Nothing Then
            Return True
        Else
            Return False
        End If
    End Function
    '
    Public Function DameTipo(eTipo As DocumentType, Optional extension As String = "") As String
        Dim dTipo As String = "_"
        Dim template As String = ""
        '
        If eTipo = DocumentType.Project Then
            dTipo &= eTipo.ToString.ToUpper
        ElseIf eTipo = DocumentType.Family Then
            dTipo &= eTipo.ToString.ToUpper
        ElseIf eTipo = DocumentType.Template Then
            If extension <> "" Then
                If extension.ToUpper.Contains("RFT") OrElse extension.ToUpper.Contains("RTE") Then
                    template = "_TEMPLATE"
                End If
            End If
        ElseIf eTipo = DocumentType.IFC Then
            dTipo &= eTipo.ToString.ToUpper
        ElseIf eTipo = DocumentType.BuildingComponent Then
            dTipo &= eTipo.ToString.ToUpper
        ElseIf eTipo = DocumentType.Other Then
            dTipo &= eTipo.ToString.ToUpper
        End If
        Return dTipo & template
    End Function
End Module
