﻿Imports UpdaterAddin
Public Class frmInicio
    Private Sub FrmInicio_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        Dim Sw As New System.Diagnostics.Stopwatch
        Sw.Start()
        txtDatos.Text = ""
        txtDatos.Text = DLLs.DLLs_Listar()
        lblTotal.Text = "Total = " & DLLs.lDlls.Count & " (" & Math.Round(Sw.Elapsed.Milliseconds / 1000, 2) & ")"
        DLLs.lDlls = Nothing
        Sw = Nothing
        'Assemblies_Listar()
        'Process_Listar()
    End Sub
    '
    Public Sub Assemblies_Listar()
        txtDatos.Text = ""
        Dim mensaje As String = ""
        For Each a In AppDomain.CurrentDomain.GetAssemblies
            mensaje &= "Assembly Name = " & a.GetName().ToString & vbCrLf
        Next
        txtDatos.Text = mensaje
    End Sub
    Public Sub Process_Listar()
        txtDatos.Text = ""
        Dim mensaje As String = ""
        Dim ps As Process() = Process.GetProcessesByName("REVIT")
        If ps.Count = 0 Then
            txtDatos.Text = "REVIT no está abierto"
            Exit Sub
        End If
        '
        For Each p As Process In ps
            mensaje &= "Proceso: " & p.ProcessName & vbCrLf & "Modulos:" & vbCrLf
            mensaje &= StrDup(80, "*") & vbCrLf
            For Each m As ProcessModule In p.Modules
                Dim filename As String = m.FileName
                For Each Folder As String In DLLs.DirIni
                    If DLLs.soloDirIni AndAlso filename.ToLower.StartsWith(Folder) = False Then Continue For
                    '
                    mensaje &= DLLs.t & "Filename = " & filename & vbCrLf
                    mensaje &= DLLs.t & "InternalName = " & m.FileVersionInfo.InternalName & vbCrLf
                    mensaje &= DLLs.t & "FileVersion = " & m.FileVersionInfo.FileVersion & vbCrLf
                    mensaje &= StrDup(80, "*") & vbCrLf
                Next
            Next
        Next
        txtDatos.Text = mensaje
    End Sub
End Class
