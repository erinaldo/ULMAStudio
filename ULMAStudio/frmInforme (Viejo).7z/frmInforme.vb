﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms
Public Class frmInforme
    'Public informe As ReportViewer
    Public filas As New List(Of filaDatos)()
    Public view As String
    Private Sub FrmInforme_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = view
        Dim ReportViewer1 As New ReportViewer
        ReportViewer1.Dock = DockStyle.Fill
        ReportViewer1.LocalReport.DataSources.Clear()
        ReportViewer1.ProcessingMode = ProcessingMode.Local
        ReportViewer1.LocalReport.EnableExternalImages = True
        ReportViewer1.SetDisplayMode(DisplayMode.PrintLayout)
        ' Crear y asignar los parámetros
        Dim parametros As ReportParameter() = New ReportParameter(0) {}
        parametros(0) = New ReportParameter("nView", view)
        '
        ' Asignar DataSource
        'informe.LocalReport.ReportEmbeddedResource = "Report1.rdlc"
        ReportViewer1.LocalReport.DataSources.Add(New ReportDataSource("filas", filas))
        ReportViewer1.LocalReport.ReportPath = IO.Path.Combine(_dirApp, "Report1.rdlc")
        ReportViewer1.LocalReport.SetParameters(parametros)
        '
        ReportViewer1.RefreshReport()
        Me.Controls.Add(ReportViewer1)
    End Sub
End Class